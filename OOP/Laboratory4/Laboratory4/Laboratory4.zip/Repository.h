#pragma once
#include "Model.h"


typedef struct {
	element* elements;
	int capacity;
	int size;
} repository;


repository* createRepository();

void destroyRepository(repository* repository_to_destroy);

int add(repository* repository_pointer, element barricade_pointer);

int update(repository* repository_pointer, int location_code, element new_barricade);

int delete(repository* repository_pointer, int location_code);