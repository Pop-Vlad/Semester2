#include "Controller.h"



Controller::Controller(Repository* repository) {
	this->repository = repository;
}


Controller::~Controller() {

}


bool Controller::add(char* input_id, char* input_size, char* input_infection_level, char* input_microfragments, char* input_photograph) {
	if (strcmp(input_id, "") == 0 || strcmp(input_size, "") == 0 || strcmp(input_infection_level, "") == 0 ||
		strcmp(input_microfragments, "") == 0 || strcmp(input_photograph, "") == 0) {
		throw std::exception();
	}
	char* id = input_id;
	char dimensions[3][10];
	char* current_part = NULL;
	current_part = strtok(input_size, "Xx");
	if (current_part == NULL) {
		throw std::exception();
	}
	strcpy(dimensions[0], current_part);
	current_part = strtok(NULL, "Xx");
	if (current_part == NULL) {
		throw std::exception();
	}
	strcpy(dimensions[1], current_part);
	current_part = strtok(NULL, "Xx");
	if (current_part == NULL) {
		throw std::exception();
	}
	strcpy(dimensions[2], current_part);
	triple size;
	size.length = atoi(dimensions[0]);
	size.width = atoi(dimensions[1]);
	size.height = atoi(dimensions[2]);
	double infection_level = atof(input_infection_level);
	int microfragments = atoi(input_microfragments);
	char* photograpg = input_photograph;
	AnomalousFragment* new_fragment = new AnomalousFragment(id, size, infection_level, microfragments, photograpg);
	return this->repository->add(new_fragment);
}


bool Controller::update(char* input_id, char* input_new_size, char* input_new_infection_level, char* input_new_microfragments, char* input_new_photograph) {
	if (strcmp(input_id, "") == 0 || strcmp(input_new_size, "") == 0 || strcmp(input_new_infection_level, "") == 0 ||
		strcmp(input_new_microfragments, "") == 0 || strcmp(input_new_photograph, "") == 0) {
		throw std::exception();
	}
	char* id = input_id;
	char dimensions[3][10];
	char* current_part = NULL;
	current_part = strtok(input_new_size, "Xx");
	if (current_part == NULL) {
		throw std::exception();
	}
	strcpy(dimensions[0], current_part);
	current_part = strtok(NULL, "Xx");
	if (current_part == NULL) {
		throw std::exception();
	}
	strcpy(dimensions[1], current_part);
	current_part = strtok(NULL, "Xx");
	if (current_part == NULL) {
		throw std::exception();
	}
	strcpy(dimensions[2], current_part);
	triple size;
	size.length = atoi(dimensions[0]);
	size.width = atoi(dimensions[1]);
	size.height = atoi(dimensions[2]);
	double infection_level = atof(input_new_infection_level);
	int microfragments = atoi(input_new_microfragments);
	char* photograpg = input_new_photograph;
	AnomalousFragment* new_fragment = new AnomalousFragment(id, size, infection_level, microfragments, photograpg);
	return this->repository->update(id, new_fragment);
}


bool Controller::remove(char* input_id) {
	char* id = input_id;
	return this->repository->remove(id);
}


void Controller::listAll(char* buffer) {
	strcpy(buffer, "");
	for (int i = 0; i < this->repository->getSize(); i++) {
		AnomalousFragment* current_fragment = this->repository->getElement(i);
		strcat(buffer, current_fragment->id);
		strcat(buffer, " ");
		strcat(buffer, to_string(current_fragment->size.length).c_str());
		strcat(buffer, "X");
		strcat(buffer, to_string(current_fragment->size.width).c_str());
		strcat(buffer, "X");
		strcat(buffer, to_string(current_fragment->size.height).c_str());
		strcat(buffer, " ");
		strcat(buffer, to_string(current_fragment->infection_level).c_str());
		strcat(buffer, " ");
		strcat(buffer, to_string(current_fragment->microfragments).c_str());
		strcat(buffer, " ");
		strcat(buffer, current_fragment->photograph);
		strcat(buffer, "\n");
	}
}