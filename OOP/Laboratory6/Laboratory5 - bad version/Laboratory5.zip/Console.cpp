#include "Console.h"



Console::Console(Controller* controller) {
	this->controller = controller;
	char input[20];
	cout << "Choose the mode: ";
	gets_s(input);
	if (strcmp(input, "mode A") == 0 || strcmp(input, "mode a") == 0) {
		this->mode = 'A';
	}
	else {
		this->mode = NULL;
	}
}


Console::~Console() {
	
}


void Console::run() {
	char command[20];
	char parameters[5][20];
	if (this->mode == 'A') {
		while (true) {
			try {
				this->readCommand(command, parameters);
				if (strcmp(command, "add") == 0) {
					if (this->controller->add(parameters[0], parameters[1], parameters[2], parameters[3], parameters[4])) {
						cout << "Fragment successfully added\n\n";
					}
					else {
						cout << "Cannot add fragment\n\n";
					}
				}
				else if (strcmp(command, "update") == 0) {
					if (this->controller->update(parameters[0], parameters[1], parameters[2], parameters[3], parameters[4])) {
						cout << "Fragment successfully updated\n\n";
					}
					else {
						cout << "Cannot update fragment\n\n";
					}
				}
				else if (strcmp(command, "delete") == 0) {
					if (this->controller->remove(parameters[0])) {
						cout << "Fragment successfully deleted\n\n";
					}
					else {
						cout << "Cannot delete fragment\n\n";
					}
				}
				else if (strcmp(command, "list") == 0) {
					char buffer[1000];
					this->controller->listAll(buffer);
					cout << buffer << "\n";
				}
				else if (strcmp(command, "exit") == 0) {
					return;
				}
				else {
					cout << "Unrecognised command!\n\n";
				}
			}
			catch (exception&) {
				cout << "What?\n\n";
			}
		}
	}
	else {
		return;
	}
}


void Console::readCommand(char command[20], char parameters[5][20]) {
	const char delimiters[] = " ,";
	char keyboard_input[120];
	char* current_word;
	
	cout << ">>>";
	gets_s(keyboard_input);
	if (strcmp(keyboard_input, "\0") == 0) {
		throw std::exception();
	}
	current_word = strtok(keyboard_input, delimiters);
	strcpy(command, current_word);

	for (int i = 0; i < 5; i++) {
		current_word = strtok(NULL, delimiters);
		if (current_word == NULL) {
			strcpy(parameters[i], "\0");
		}
		else {
			strcpy(parameters[i], current_word);
		}
	}
}