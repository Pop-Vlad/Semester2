#pragma once

#include <cstdlib>
#include <exception>

#include "Repository.h"

using namespace std;



class Controller {


private:

	Repository* repository;


public:

	Controller(Repository* repository);

	~Controller();

	bool add(char* input_id, char* input_size, char* input_infection_level, char* input_microfragments, char* input_photograph);

	bool update(char* input_id, char* input_new_size, char* input_new_infection_level, char* input_new_microfragments, char* input_new_photograph);

	bool remove(char* input_id);

	void listAll(char* buffer);


};