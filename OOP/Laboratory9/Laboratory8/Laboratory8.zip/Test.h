#pragma once

#include "Controller.h"



class Test {


public:

	static void testMode();
	static void testFileLocation();

	static void testAdd();
	static void testUpdate();
	static void testDelete();
	static void testListA();

	static void testNext();
	static void testListB();
	static void testMyListPlusSave();

	static void testAll();


};