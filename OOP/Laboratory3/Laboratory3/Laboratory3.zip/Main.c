#include "Console.h"

int main() {
	repository* repository_object = createRepository(1000);
	controller* controller_object = createController(repository_object);
	console* console_object = createConsole(controller_object);
	run(console_object);
	destroyRepository(repository_object);
	destroyController(controller_object);
	destroyConsole(console_object);
	return 0;
}