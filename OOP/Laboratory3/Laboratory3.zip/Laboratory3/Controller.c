#include <stdlib.h>
#include <string.h>
#include "Controller.h"


controller* createController(repository* repository_pointer) {
	controller* new_controller = (controller*)malloc(sizeof(controller));
	new_controller->the_repository = repository_pointer;
	return new_controller;
}


void destroyController(controller* controller_pointer) {
	free(controller_pointer);
}


int addController(controller* controller_pointer, char* location_code, char* visibility_in_area, char* barricade_type, char* barricade_sturdiness) {
	int location_code_integer = atoi(location_code);
	int barricade_sturdiness_integer = atoi(barricade_sturdiness);
	barricade* new_barricade = createBarricade(location_code_integer, visibility_in_area, barricade_type, barricade_sturdiness_integer);
	add(controller_pointer->the_repository, new_barricade);
	return 0;
}


int updateController(controller* controller_pointer, char* location_code, char* new_visibility_in_area, char* new_barricade_type, char* new_barricade_sturdiness) {
	int location_code_integer = atoi(location_code);
	int new_barricade_sturdiness_integer = atoi(new_barricade_sturdiness);
	barricade* new_barricade = createBarricade(location_code_integer, new_visibility_in_area, new_barricade_type, new_barricade_sturdiness_integer);
	update(controller_pointer->the_repository, location_code_integer, new_barricade);
	return 0;
}


int deleteController(controller* controller_pointer, char* location_code) {
	int location_code_integer = atoi(location_code);
	delete(controller_pointer->the_repository, location_code_integer);
	return 0;
}


void listAll(controller* controller_pointer, char* string_to_print) {
	int i;
	char location_code_string[20];
	char barricade_sturdiness_string[20];
	strcpy(string_to_print, "");
	for (i = 0; i < controller_pointer->the_repository->size; i++) {
		strcat(string_to_print, "Location code: ");
		itoa(controller_pointer->the_repository->elements[i]->location_code, location_code_string, 10);
		strcat(string_to_print, location_code_string);
		strcat(string_to_print, ", visibility in area: ");
		strcat(string_to_print, controller_pointer->the_repository->elements[i]->visibility_in_area);
		strcat(string_to_print, ", barricade type: ");
		strcat(string_to_print, controller_pointer->the_repository->elements[i]->barricade_type);
		strcat(string_to_print, ", barricade sturdiness: ");
		itoa(controller_pointer->the_repository->elements[i]->barricade_sturdiness, barricade_sturdiness_string, 10);
		strcat(string_to_print, barricade_sturdiness_string);
		strcat(string_to_print, "\n");
	}
}


void listType(controller* controller_pointer, char* test_barricade_type, char* string_to_print) {
	int i;
	char location_code_string[20];
	char barricade_sturdiness_string[20];
	for (i = 0; i < controller_pointer->the_repository->size; i++) {
		if (strcmp(controller_pointer->the_repository->elements[i]->barricade_type, test_barricade_type) == 0) {
			strcpy(string_to_print, "Location code: ");
			itoa(controller_pointer->the_repository->elements[i]->location_code, location_code_string, 10);
			strcat(string_to_print, location_code_string);
			strcat(string_to_print, ", visibility in area: ");
			strcpy(string_to_print, controller_pointer->the_repository->elements[i]->visibility_in_area);
			strcat(string_to_print, ", barricade type: ");
			strcpy(string_to_print, controller_pointer->the_repository->elements[i]->barricade_type);
			strcat(string_to_print, ", barricade sturdiness: ");
			itoa(controller_pointer->the_repository->elements[i]->barricade_sturdiness, barricade_sturdiness_string, 10);
			strcat(string_to_print, barricade_sturdiness_string);
			strcat(string_to_print, "\n");
		}
	}
}


void listAllTesting(controller* controller_pointer, char* string_to_print) {
	int i;
	char location_code_string[20];
	char barricade_sturdiness_string[20];
	strcpy(string_to_print, "");
	for (i = 0; i < controller_pointer->the_repository->size; i++) {
		strcat(string_to_print, "");
		itoa(controller_pointer->the_repository->elements[i]->location_code, location_code_string, 10);
		strcat(string_to_print, location_code_string);
		strcat(string_to_print, " ");
		strcat(string_to_print, controller_pointer->the_repository->elements[i]->visibility_in_area);
		strcat(string_to_print, " ");
		strcat(string_to_print, controller_pointer->the_repository->elements[i]->barricade_type);
		strcat(string_to_print, " ");
		itoa(controller_pointer->the_repository->elements[i]->barricade_sturdiness, barricade_sturdiness_string, 10);
		strcat(string_to_print, barricade_sturdiness_string);
		strcat(string_to_print, "\n");
	}
}


void listTypeTesting(controller* controller_pointer, char* test_barricade_type, char* string_to_print) {
	int i;
	char location_code_string[20];
	char barricade_sturdiness_string[20];
	for (i = 0; i < controller_pointer->the_repository->size; i++) {
		if (strcmp(controller_pointer->the_repository->elements[i]->barricade_type, test_barricade_type) == 0) {
			strcpy(string_to_print, "");
			itoa(controller_pointer->the_repository->elements[i]->location_code, location_code_string, 10);
			strcat(string_to_print, location_code_string);
			strcat(string_to_print, " ");
			strcpy(string_to_print, controller_pointer->the_repository->elements[i]->visibility_in_area);
			strcat(string_to_print, " ");
			strcpy(string_to_print, controller_pointer->the_repository->elements[i]->barricade_type);
			strcat(string_to_print, " ");
			itoa(controller_pointer->the_repository->elements[i]->barricade_sturdiness, barricade_sturdiness_string, 10);
			strcat(string_to_print, barricade_sturdiness_string);
			strcat(string_to_print, "\n");
		}
	}
}