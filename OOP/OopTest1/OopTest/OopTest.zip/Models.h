


typedef struct {
	int x_position;
	int y_position;
} Tile;