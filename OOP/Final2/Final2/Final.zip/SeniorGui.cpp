#include "SeniorGui.h"

SeniorGui::SeniorGui(QWidget *parent) : GUI(parent)
{
	ui.setupUi(this);
}

SeniorGui::~SeniorGui()
{
}
