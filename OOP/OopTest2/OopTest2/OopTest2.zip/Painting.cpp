#include "Painting.h"



Painting::Painting(const std::string& input_title, const std::string& input_artist, const int& input_year) {
	this->title = input_title;
	this->artist = input_artist;
	this->year = input_year;
}
