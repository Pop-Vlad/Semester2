#include "Laboratory11.h"

Laboratory11::Laboratory11(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
